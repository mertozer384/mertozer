package com.cybertek.tests.pojo;

import lombok.Data;

@Data
public class Spartan {
    private int id;
    private String name;
    private String gender;
    private long phone;
}
