package com.cybertek.tests.pojo;

import lombok.Data;

@Data
public class Link {
    private String rel, href;
}
