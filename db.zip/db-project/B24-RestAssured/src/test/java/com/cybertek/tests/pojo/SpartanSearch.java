package com.cybertek.tests.pojo;

import lombok.Data;

import java.util.List;

@Data
public class SpartanSearch {

    private List<Spartan> content;

    private int totalElement;

}