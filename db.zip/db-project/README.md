# db-project
SQL and Database class repository

All SQL Queries we wrote in SQL Classes can be found in [Queries](Queries) folder.
